import os
import sys



def main(inFileName):
    with open(inFileName, 'rb') as f:
        data = f.read()
    
    txtlst = []
    count = 0
    for c in data:
        txtlst.append('0x%02x,' % ord(c))
        if (count % 15) == 0:
            txtlst.append('\n') 
        count += 1    
    
    text = 'const unsigned int dllbuf_size = %d;\n' % len(data) 
    text += 'const unsigned char dllbuf[] = {' + ''.join(txtlst) + '};';
    
    with open(inFileName + "_gen.h", 'w') as f:
         f.write(text)



main(sys.argv[1])
