
from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
import os

PORT_NUMBER = 8080

lastImage = None

class myHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        print "got GET", self.path
        
        if self.path.startswith("/lastimage.png"):
            self.send_response(200)
            self.send_header('Content-type','image/png')
            self.end_headers()
            # Send the html message
            self.wfile.write(lastImage)
            print "sent image", len(lastImage)
        else:
            filename = self.path[1:]
            if len(filename) == 0:
                filename == "index.html"
            if os.path.exists(filename):
                print "getting file", filename
                with open(filename, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header('Content-type','text/html')
                self.end_headers()
                self.wfile.write(data)
            
            
    
    def do_POST(self):
        print "got POST", self.path
        data = self.rfile.read()
        global lastImage
        lastImage = data
        print "saved image", len(data)
        

def main():
    server = HTTPServer(('', PORT_NUMBER), myHandler)
    print 'Started httpserver on port ' , PORT_NUMBER

    server.serve_forever()


main()