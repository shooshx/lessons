import socket
import struct
import sys

def encodeDomain(name):
    s = name.split('.')
    ret = ""
    for p in s:
        ret += chr(len(p))
        ret += p
    ret += chr(0)
    return ret
    
def n2s(lstn):
    ret = ''
    for n in lstn:
        ret += chr(n)
    return ret
    
def strIp(d):
    return "%s.%s.%s.%s" % (ord(d[0]), ord(d[1]), ord(d[2]), ord(d[3]))
    
def extractDomain(reply):
    d = ""
    while True:
        sz = ord(reply[0])
        if (sz & 0xC0) != 0: # a pointer
            ptr = struct.unpack('!H', reply[0:2])[0] & 0x3f
            reply = reply[2:]
            return (reply, d + "P%d" % ptr)
            
        reply = reply[1:]
        if sz == 0:
             break
        d += reply[0:sz] + "."
        reply = reply[sz:]
    #d = d[:-1]
    return (reply, d)
 
server = ("8.8.8.8", 53) 

# http://www.ccs.neu.edu/home/amislove/teaching/cs4700/fall09/handouts/project1-primer.pdf

def parseQueryEntry(reply):
    reply, d = extractDomain(reply)
    fields = reply[0:4]
    reply = reply[4:]
    print " QUERY" , d
    return reply

def parseReplyEntry(reply):
    reply, d = extractDomain(reply)
    fields = reply[0:10]
    reply = reply[10:]
    type, cls, ttl, rdlength = struct.unpack("!HHIH", fields)
    
    data = reply[0:rdlength]
    reply = reply[rdlength:]
    
    #print repr(data)
    if type == 5:  # CNAME
        rest, data = extractDomain(data)
    elif type == 1:
        data = strIp(data)
    print "  ANSWER", d, type, cls, ttl, repr(data)
    return reply
    
#pointers make this hard...   

origReply = "" 
    
def query(name):
    
    msg = n2s([ 
            0xcc, 0xcc, # id
            0x01, 0x00, # normal query
            0x00, 0x01, # 1 question
            0x00, 0x00, # 0 answers
            0x00, 0x00, # 0 auth
            0x00, 0x00, # 0 additional
            ])
    msg += encodeDomain(name)
    msg += n2s([ 
             0x00, 0x01, # A entry
             0x00, 0x01, # ipv4
             ])

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.sendto(msg, server)
    reply, addr = s.recvfrom(1000)
    print "Got reply"
    
    global origReply
    origReply = reply
    
    header = reply[0:12]
    reply = reply[12:]
    id, flags, qCount, ansCount, authCount, addCount = struct.unpack('!HHHHHH', header)
    
    print "HEADER ", hex(id), hex(flags), qCount, ansCount, authCount, addCount
    
    print "Queries"
    for i in xrange(qCount):
        reply = parseQueryEntry(reply)
         
    print "Answers"
    for i in xrange(ansCount):
        reply = parseReplyEntry(reply)
        
    return        



query(sys.argv[1])