import socket
import struct


def nums2bytes(numsList):
    result = ''
    for n in numsList:
        result += chr(n)
    return result
    
def bytes2nums(b):
    result = []
    for c in b:
        result.append(hex(ord(c)))
    return result
    
def encodeDomain(domainStr):
    numsList = []
    splited = domainStr.split('.')
    for word in splited:
        numsList.append(len(word))
        for letter in word:
            numsList.append(ord(letter))
           
    numsList.append(00)
    return numsList    
    
def str2ip(s):
   # need the tuple() for unpacking the generator
   return "%s.%s.%s.%s" % tuple(ord(byte) for byte in s)
    
class DnsParser:
    def __init__(self, data):
        self.data = data
        
    def parseDomain(self):
        domain=""
        while True:   
            size = ord(self.data[:1])
            #print "SZ=", size
            if (size & 0xc0) == 0xc0:
                offset = struct.unpack('!H', self.data[0:2])[0] & 0x3FFF
                self.data = self.data[2:]
                return domain + "PTR%d" % offset

            self.data = self.data[1:]
            if size == 0:
                return domain[:-1]
            domain += self.data[:size]
            domain += "."
            self.data = self.data[size:]
        return domain
            
        
    def parseQuestion(self):
        d = self.parseDomain()
        #footer = self.data[0:4]
        self.data = self.data[4:]
        print "  QUESTION="+d
        return d
        
    def parseAnswer(self):
        d = self.parseDomain()
        print "  ANSWER="+d
        middler = self.data[0:10]
        self.data = self.data[10:]
        type, cls, ttl, len = struct.unpack('!HHIH', middler)
        print "  middler=", type, cls, ttl, len
        ansContent = self.data[0:len]
        print "  content=", repr(ansContent)
        if type == 1: # A type
            print "  ip=", str2ip(ansContent)
        elif type == 5:
            print "  name=", DnsParser(ansContent).parseDomain()
        
        self.data = self.data[len:]
    
class PacketInfo:
   def __init__(self):
      pass
    
def parseDns(data):
    header = data[0:12]
    print "  HEADER", bytes2nums(header)
    data = data[12:]
    # '!' means read as network order and convert to processor order
    tid, flags, qcount, acount, authcount, addcount = struct.unpack('!HHHHHH', header)
    #print hex(tid)
    #print hex(qcount)
    print "Header=", qcount, " questions", acount, " answers" 

    ret = PacketInfo()
    ret.qs = []

    p = DnsParser(data)
    for i in xrange(0, qcount):
        print "question", i+1, ":"
        ret.qs.append( p.parseQuestion() )
    
    for i in xrange(0, acount):
        print "answer", i+1, ":"
        p.parseAnswer()

    ret.tid = tid
    return ret
      
    
def client():
   s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)   

   packetNums = [ 
           0xc0, 0xde, # transaction id
           0x01, 0x00, # flags
           0x00, 0x01, # questions count
           0x00, 0x00, # answers count
           0x00, 0x00, # authority count
           0x00, 0x00, # addition count
       ] + encodeDomain('www.ynet.co.il') + [ 
           0x00, 0x01, # A type query
           0x00, 0x01, # IN type query
           ]

   packet = nums2bytes(packetNums)
   print "sending request..."
   s.sendto(packet, ("192.168.100.4", 53))
   rdata, fromaddr = s.recvfrom(1500)
   print "received response"
   parseDns(rdata)
   
def server():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)   
    s.bind( ("0.0.0.0", 53) )
    s.settimeout(1)
    while True:
        try:
            rdata, fromaddr = s.recvfrom(1500)
            print "received request"
            info = parseDns(rdata)
            
            # 0x1234 -> [12, 34]
            #    &
            # 0x00FF = 0x34, 0x1234 >> 8 = 0x12
            tidnums = [ (info.tid >> 8), (info.tid & 0xFF) ]
            
            # generate answer
            packetNums = tidnums + [           
                 0x81, 0x80, # flags
                 0x00, 0x01, # questions count
                 0x00, 0x01, # answers count
                 0x00, 0x00, # authority count
                 0x00, 0x00, # addition count
             ] + encodeDomain(info.qs[0]) + [ 
                 0x00, 0x01, # A type query
                 0x00, 0x01, # IN type query
             ] + encodeDomain(info.qs[0]) + [ 
                 0x00, 0x01, # A type query
                 0x00, 0x01, # IN type query
                 0x00, 0x00, 0x00, 0x10, # TTL
                 0x00, 0x04, # length of data
             ] + [204, 79, 197, 200]  # answer IP bing.com

            packet = nums2bytes(packetNums)
            print "sending packet ", bytes2nums(packet)
            s.sendto(packet, fromaddr)
            
            
        except socket.timeout:
            print "swag yolo"
    
    
   
server()







